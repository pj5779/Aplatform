<template>
    <button  @click="fnWrite" id="insertToTable" class="btn btn-primary">저장 &nbsp;<i class="fas fa-plus"></i></button>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

function fnWrite() {
    router.push({
        path: './insert'
    })
}
</script>

<style scoped>

</style>