<template>
    <button id="deleteToTable" class="btn btn-primary">글 삭제 &nbsp;<i class="fas fa-plus"></i></button>
</template>

<script setup>

</script>

<style scoped>

</style>
