<template>
    <button @click="fnSave" id="updateToTable" class="btn btn-primary">글 저장 &nbsp;<i class="fas fa-plus"></i></button>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import axios from 'axios';

const route = useRoute();   // url 값 가져오기
const router = useRouter(); // 경로 이동

const requestBody = reactive({ ...route.query });
const idx = ref(route.query.idx);

const title = ref('');
const author = ref('');
const contents = ref('');
const created_at = ref('');

function fnGetView() {
    if (idx.value !== undefined) {
        axios.get(`${process.env.VUE_APP_SERVER_URL}/board/${idx.value}`, {
            params: requestBody
        }).then((res) => {
            title.value = res.data.title;
            author.value = res.data.author;
            contents.value = res.data.contents;
            created_at.value = res.data.created_at;
        }).catch((err) => {
            console.log(err);
        });
    }
}
onMounted(() => {
    fnGetView();
});
function fnView(idx) {
    requestBody.idx = idx;
    router.push({
        path: './detail',
        query: requestBody
    });
}
function fnSave() {
    const apiUrl = `${process.env.VUE_APP_SERVER_URL}/board`;
    const form = {
        idx: idx.value,
        title: title.value,
        contents: contents.value,
        author: author.value
    };

    if (idx.value === undefined) {
        // INSERT
        axios.post(apiUrl, form)
            .then((res) => {
                alert('글이 저장되었습니다.');
                fnView(res.data.idx);
            }).catch((err) => {
                if (err.message.includes('Network Error')) {
                    alert('네트워크가 원활하지 않습니다.\n잠시 후 다시 시도해주세요.');
                }
            });
    } else {
        // UPDATE
        axios.patch(apiUrl, form)
            .then((res) => {
                alert('글이 저장되었습니다.');
                fnView(res.data.idx);
            }).catch((err) => {
                if (err.message.includes('Network Error')) {
                    alert('네트워크가 원활하지 않습니다.\n잠시 후 다시 시도해주세요.');
                }
            });
    }
}
</script>

<style scoped>

</style>
