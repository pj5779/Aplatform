<template>
    <button @click="fnList" class="btn btn-primary">목록으로 &nbsp;<i class="fas fa-plus"></i></button>
</template>

<script setup>
function fnList() {
    delete requestBody.idx;
    router.push({
        path: './list',
        query: requestBody
    });
}
</script>

<style scoped>

</style>