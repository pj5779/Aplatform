<template>
    <button @click="fnView" class="btn btn-primary">이동 &nbsp;<i class="fas fa-plus"></i></button>
</template>

<script setup>
import { reactive } from 'vue';
import { useRoute, useRouter } from 'vue-router';

const requestBody = reactive({ ...route.query });
const route = useRoute();
const router = useRouter();

function fnView(idx) {
    requestBody.idx = idx;
    router.push({
        path: './detail',
        query: requestBody
    });
}
</script>

<style scoped>

</style>