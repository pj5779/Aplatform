<template>
    <li>Q&A 게시판 제목1</li>
    <li>Q&A 게시판 제목2</li>
    <li>Q&A 게시판 제목3</li>
    <li>Q&A 게시판 제목4</li>
    <li>Q&A 게시판 제목5</li>
</template>

<script setup>

</script>

<style scoped>

</style>