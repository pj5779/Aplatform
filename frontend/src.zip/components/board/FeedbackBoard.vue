<template>
    <li>피드백 게시판 제목1</li>
    <li>피드백 게시판 제목2</li>
    <li>피드백 게시판 제목3</li>
    <li>피드백 게시판 제목4</li>
    <li>피드백 게시판 제목5</li>
</template>

<script setup>

</script>

<style scoped>

</style>