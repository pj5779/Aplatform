<template>
  <div>
    <HeaderView/>
    <router-view></router-view>
    <FooterView></FooterView>
  </div>
</template>

<script setup>
  import HeaderView from "./components/common/HeaderView.vue";
  import FooterView from "./components/common/FooterView.vue";
</script>

<style>

</style>