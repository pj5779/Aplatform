<template>
    <section class="page-header page-header-modern bg-color-grey page-header-md">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 align-self-center p-static order-2 text-center">
                                    <h1 class="text-dark font-weight-bold text-8">피드백게시판</h1>
                                    <span class="sub-title text-dark">도움을 받아보세요!</span>
                                </div>
                                <div class="col-md-12 align-self-center order-1">
                                    <ul class="breadcrumb d-block text-center">
                                        <li><a href="/">Home</a></li>
                                        <li class="active">피드백게시판</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </section>
    
    
                    <section id="examples" class="section section-default">
                        <div class="container">
                        <section class="card card-admin">
                            <header class="card-header">
                                <div class="card-actions">
                                    <a href="#" class="card-action card-action-toggle" data-card-toggle=""></a>
                                    <a href="#" class="card-action card-action-dismiss" data-card-dismiss=""></a>
                                </div>
                                <h2 class="card-title">피드백게시판</h2>
                            </header>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="mb-3">
                                          <MovetoDetailButton />
                                        </div>
                                    </div>
                                </div>
                                <FeedbackBoard />
                            </div>
                        </section>
                    </div>
                </section>
    
    
                    
    </template>
    
    <script setup>
    import MovetoDetailButton from '../components/button/MovetoDetailButton.vue';
    import FeedbackBoard from '../components/board/FeedbackBoard.vue';
    </script>

    
    <style lang="scss" scoped>
    
    </style>