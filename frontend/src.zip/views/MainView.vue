<template>
    <div class="container-fluid">
        <div class="row">
            <div class="col-half-section col-half-section-right py-5 ms-auto">
                <div class="p-3">
                <h4>일반게시판</h4>
                    <ul class="list list-icons list-primary list-borders">
                        <GeneralBoard />
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 p-0">
                <div class="h-400px m-0">
                    <div class="row m-0">
                        <div class="col-half-section col-half-section-left py-5">
                            <div class="p-3">
                                <h4>피드백게시판</h4>
                                <ul class="list list-icons list-primary list-borders">
                                    <FeedBackBoard />
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-half-section col-half-section-right py-5 ms-auto">
                <div class="p-3">
   
                </div>
            </div>
            <div class="col-lg-6 p-0">
                <div class="h-400px m-0">
                    <div class="row m-0">
                        <div class="col-half-section col-half-section-left py-5">
                            <div class="p-3">
                                <h4>Q&A게시판</h4>
                                <ul class="list list-icons list-primary list-borders">
                                    <QnABoard />
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
</template>

<script setup>
import GeneralBoard from '../components/board/GeneralBoard.vue';
import FeedBackBoard from '../components/board/FeedbackBoard.vue';
import QnABoard from '../components/board/QnABoard.vue';
</script>

<style lang="scss" scoped>

</style>