<template>
    <section id="examples" class="section section-default">
        <div class="container">
            <section class="card card-admin">
                <header class="card-header">
                    <div class="card-actions">
                        <a href="#" class="card-action card-action-toggle" data-card-toggle=""></a>
                        <a href="#" class="card-action card-action-dismiss" data-card-dismiss=""></a>
                    </div>
                    <h2 class="card-title">일반게시판</h2>
                </header>
            </section>
    
            <div class="mb-3">
                <label for="title" class="form-label">제목</label>
                <input type="email" class="form-control" id="title" placeholder="제목을 입력하세요">
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">내용</label>
                <textarea class="form-control" id="content" rows="3" placeholder="내용을 입력하세요"></textarea>
            </div>
            <SaveButton />
        </div>
        
    </section>
    </template>
    
<script setup>
import SaveButton from '../components/button/SaveButton.vue';


</script>
    
    <style scoped>
    
    </style>